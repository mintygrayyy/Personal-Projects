import java.io.InputStreamReader;

import controller.ImageController;
import controller.ImageControllerImpl;
import model.ImageModel;
import model.ImageModelImpl;
import view.ImageView;
import view.ImageViewImpl;

/**
 * Class that allows the user to run the image processor.
 */
public class ImageProcessor {
  /**
   * Method to run the image processor.
   *
   * @param args arguments
   */
  public static void main(String[] args) {
    ImageModel model = new ImageModelImpl();
    ImageView view = new ImageViewImpl(System.out);
    Readable rd = new InputStreamReader(System.in);
    ImageController controller = new ImageControllerImpl(model, view, rd);

    controller.imageProcessor();
  }
}
