package filter;

/**
 * Greyscales the image.
 */
public class Greyscale extends Color {

  public Greyscale() {
    super(0.2126, 0.7152, 0.0722, 0.2126, 0.7152, 0.0722,
            0.2126, 0.7152, 0.0722);
  }
}
